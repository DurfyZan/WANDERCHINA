
# 子网页智能体数据生成与标注系统

一个基于 Python 的多智能体社交媒体数据生成与标注系统，支持模拟真实用户在社区/社交平台的发帖、评论、互动行为。

## 核心特性

- **多智能体编排**: 使用 LangGraph 构建复杂的社区互动流程
- **去 AI 化拟人化**: 注入网络用语、表情符号、小错误等使内容更真实
- **大模型适配**: 支持 DeepSeek、Qwen 等主流模型，自动剥离思考链
- **G-Eval 评估**: 基于大模型的自动质量评估，未达标自动重跑
- **自动标注**: 情感分析、意图识别、话题标签自动生成
- **标准格式导出**: 支持 Alpaca 和 ShareGPT 微调格式

## 技术栈

- **核心语言**: Python 3.11+
- **智能体框架**: LangGraph
- **异步网络**: HTTPX + AsyncIO
- **数据验证**: Pydantic v2
- **数据导出**: JSON Lines

## 项目结构

```
.
├── src/
│   ├── core/
│   │   ├── schemas.py          # Pydantic 数据模型
│   │   ├── llm_router.py       # 大模型适配器
│   │   ├── evaluator.py        # G-Eval 评估器
│   │   └── annotator.py        # 自动标注器
│   ├── agents/
│   │   ├── persona_manager.py  # 人设管理和去AI化引擎
│   │   └── graph_workflow.py   # 社区互动图
│   └── data/
│       └── dataset_exporter.py # 数据集导出器
├── output/                     # 输出目录
├── .env.example               # 环境变量示例
├── requirements.txt           # 依赖
└── main.py                    # 入口脚本
```

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置环境变量

复制 `.env.example` 为 `.env` 并填写你的 API 密钥：

```bash
cp .env.example .env
# 编辑 .env 文件
```

### 3. 运行示例

```bash
python main.py
```

## 核心模块说明

### PersonaManager (人设管理)

预定义三种人设：
- **Tourist**: 外国游客，带口音的中文，偶尔夹英文
- **Local**: 本地居民，地道方言，接地气
- **Expat**: 在中国的外籍人士，中英文混合

### HumanizationEngine (去AI化引擎)

- 添加 Emoji 表情
- 注入网络用语/英文俚语
- 概率性拼写错误
- 添加感叹号增强情绪

### CommunityInteractionGraph (社区互动图)

使用 LangGraph 构建流程：
1. Tourist 发帖
2. Local 回复
3. Expat 回复
4. 循环 3 轮

### GEvaluator (评估器)

评估维度：
- **拟人度**: 1-5分，检查是否像真人
- **连贯性**: 1-5分，检查对话逻辑
- 未达标自动重跑（最多3次）

### AutoAnnotator (自动标注)

自动提取：
- `sentiment`: 情感倾向
- `intent`: 用户意图
- `topic_tags`: 话题标签
- `key_themes`: 核心主题

### DatasetExporter (导出器)

支持格式：
- **Alpaca**: 单轮指令微调格式
- **ShareGPT**: 多轮对话格式
- **Raw**: 原始 JSON 格式

## 数据模型

```python
class SocialDataPayload:
    post_id: str
    main_content: str
    location: str
    author_persona: AgentPersona
    interactions: List[InteractionNode]
    annotations: Dict[str, Any]
```

## 扩展开发

### 添加新人设

在 `persona_manager.py` 中添加新的 `create_*_persona` 方法和对应模板。

### 自定义场景

修改 `main.py` 中的 `scenario` 和 `location` 变量。

### 更换大模型

在 `.env` 中配置不同的 `*_API_KEY` 和 `*_BASE_URL`，在代码中切换 provider。
