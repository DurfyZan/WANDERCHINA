# 子网页社区 - 多智能体数据生成与标注系统

基于 React 19 + TypeScript + Vite 的高保真社交媒体仿真与数据标注平台。

## 🚀 快速开始

### 环境要求

- Node.js >= 18.0.0
- npm >= 9.0.0

### 安装依赖

```bash
npm install
```

### 启动开发服务器

```bash
npm run dev
```

访问 http://localhost:5173 查看应用。

### 构建生产版本

```bash
npm run build
```

## 📁 项目结构

```
src/
├── components/          # React 组件
│   ├── community/      # 社区相关组件
│   │   ├── PostCard.tsx              # 帖子卡片
│   │   ├── PostCardWithAnnotation.tsx # 带标注功能的帖子卡片
│   │   └── CommentTree.tsx           # 嵌套评论树
│   ├── dashboard/      # 控制台相关组件
│   │   ├── GenerationConfigForm.tsx # 任务配置表单
│   │   └── ExportWizard.tsx          # 导出向导
│   ├── evaluation/     # 评估相关组件
│   │   └── EvaluationPanel.tsx      # G-Eval 评估面板
│   └── layout/         # 布局组件
│       └── Sidebar.tsx              # 侧边栏导航
├── hooks/              # React Hooks
│   └── useCommunityData.ts          # 社区数据与SSE流式生成
├── pages/              # 页面组件
│   ├── CommunityPage.tsx            # 社区沙盒页面
│   └── DashboardPage.tsx            # 控制台页面
├── types/              # TypeScript 类型定义
│   └── index.ts                     # 核心接口定义
└── lib/                # 工具函数
    └── utils.ts                     # cn() 等工具函数
```

## 🎨 核心功能

### 1. 多智能体社区沙盒 (Community Sandbox)

- 模拟真实社交媒体平台的高保真卡片式布局
- 支持多语言智能体（游客、本地人、expat）
- 国籍国旗角标和角色标签
- 多层嵌套评论树（盖楼效果）
- 🧠 思考链折叠面板（支持推理模型）

### 2. 协同标注与评估

- 情感 Badge 一键切换（正面/焦虑/吐槽）
- Tag 输入框自动补全
- 双击文本行内编辑（Inline Edit）
- G-Eval 评估可视化（拟人度、连贯性、文化匹配度）
- 不合格时显示 Judge Agent 反馈和重新生成按钮

### 3. 任务控制台

- 基座模型选择（DeepSeek-V3/R1、Qwen3-72B/235B）
- 参数滑块（Temperature、Top-P、最大轮数）
- 场景剧本选择器
- 导出格式切换（Alpaca / ShareGPT）
- 实时 JSONL 预览和下载

### 4. SSE 流式生成

- Mock Server-Sent Events 效果
- 主贴逐字蹦出动画
- 思考链流式展开
- 评论依次流式加载
- 丝滑自然的动态效果

## 🔧 技术栈

- **React 19** + TypeScript
- **Vite** - 极速构建工具
- **Tailwind CSS** - 原子化样式
- **TanStack Query v5** - 数据获取与缓存
- **Lucide React** - 现代化图标库
- **Clsx** - 条件类名合并

## 📦 核心数据结构

### AgentPersona

```typescript
interface AgentPersona {
  agent_id: string
  role_type: 'Tourist' | 'Local' | 'Expat'
  nationality: string
  language_style: string
  avatar_url: string
}
```

### InteractionNode

```typescript
interface InteractionNode {
  node_id: string
  parent_id: string | null
  agent: AgentPersona
  content: string
  thinking_process?: string
  timestamp: string
}
```

### MetadataAndEval

```typescript
interface MetadataAndEval {
  sentiment: 'positive' | 'neutral' | 'negative' | 'anxious'
  intent: string
  tags: string[]
  scores: {
    human_likeness: number    // 1-5
    coherence: number         // 1-5
    cultural_fit: number      // 1-5
  }
  is_passed: boolean
  feedback?: string
}
```

## 🎯 使用流程

1. **配置任务**：在控制台页面选择模型、参数和场景
2. **生成内容**：点击开始生成，观察 AI 智能体流式生成帖子和评论
3. **审计标注**：在社区页面查看思考链、切换情感标签、添加自定义标签
4. **质量评估**：查看 G-Eval 评分，不合格时触发重新生成
5. **导出数据**：在控制台页面选择导出格式并下载 JSONL 文件

## 📝 注意事项

- Mock 数据会自动在页面加载时生成，无需后端
- 导出功能使用浏览器原生下载，实际使用需对接后端 API
- 所有组件支持 Tailwind CSS 主题定制

## 🤝 开发指南

- 遵循 React 19 + TypeScript 最佳实践
- 使用 Tailwind CSS 原子类，保持代码简洁
- 所有组件使用 `cn()` 工具函数处理条件类名
- TypeScript 严格模式已启用

## 📄 License

MIT
